# -*- coding: utf8 -*-
# Copyright (c) 2017-2018 THL A29 Limited, a Tencent company. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from tencentcloud.common.abstract_model import AbstractModel


class BeatTips(AbstractModel):
    """打击原因

    """

    def __init__(self):
        """
        :param Keyword: 命中关键词
        :type Keyword: str
        :param EvilType: 恶意类型，同type说明
        :type EvilType: int
        :param Level: 恶意等级：0：无恶意 1~3：数字越小恶意等级越高
        :type Level: int
        """
        self.Keyword = None
        self.EvilType = None
        self.Level = None


    def _deserialize(self, params):
        self.Keyword = params.get("Keyword")
        self.EvilType = params.get("EvilType")
        self.Level = params.get("Level")


class BspAudioRecognitionRequest(AbstractModel):
    """BspAudioRecognition请求参数结构体

    """

    def __init__(self):
        """
        :param FileUrl: 音频的URL地址
        :type FileUrl: str
        :param FileName: 音频名称
        :type FileName: str
        """
        self.FileUrl = None
        self.FileName = None


    def _deserialize(self, params):
        self.FileUrl = params.get("FileUrl")
        self.FileName = params.get("FileName")


class BspAudioRecognitionResponse(AbstractModel):
    """BspAudioRecognition返回参数结构体

    """

    def __init__(self):
        """
        :param Data: 识别信息
        :type Data: :class:`tencentcloud.contentsecurity.v20190305.models.TextData`
        :param RequestId: 唯一请求 ID，每次请求都会返回。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self.Data = None
        self.RequestId = None


    def _deserialize(self, params):
        if params.get("Data") is not None:
            self.Data = TextData()
            self.Data._deserialize(params.get("Data"))
        self.RequestId = params.get("RequestId")


class BspCloseServiceRequest(AbstractModel):
    """BspCloseService请求参数结构体

    """

    def __init__(self):
        """
        :param ServicesId: 内容安全服务ID标识
        :type ServicesId: int
        :param UIN: 客户uin
        :type UIN: int
        :param APPID: 客户appid
        :type APPID: int
        """
        self.ServicesId = None
        self.UIN = None
        self.APPID = None


    def _deserialize(self, params):
        self.ServicesId = params.get("ServicesId")
        self.UIN = params.get("UIN")
        self.APPID = params.get("APPID")


class BspCloseServiceResponse(AbstractModel):
    """BspCloseService返回参数结构体

    """

    def __init__(self):
        """
        :param Data: 内容安全服务关闭信息
        :type Data: str
        :param RequestId: 唯一请求 ID，每次请求都会返回。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self.Data = None
        self.RequestId = None


    def _deserialize(self, params):
        self.Data = params.get("Data")
        self.RequestId = params.get("RequestId")


class BspImageRecognitionRequest(AbstractModel):
    """BspImageRecognition请求参数结构体

    """

    def __init__(self):
        """
        :param FileName: 图片名称
        :type FileName: str
        :param FileUrl: 图片的 URL 地址  与FileContent二选一
        :type FileUrl: str
        :param FileContent: 对图片内容 Base64 位编码值 与FileUrl二选一
        :type FileContent: str
        """
        self.FileName = None
        self.FileUrl = None
        self.FileContent = None
        # self.Uin = None
        # self.SubAccountUin = None
        # self.RequestId = None
        # self.Appid = None



    def _deserialize(self, params):
        self.FileName = params.get("FileName")
        self.FileUrl = params.get("FileUrl")
        self.FileContent = params.get("FileContent")
        # self.Appid = params.get("Appid")
        # self.Uin = params.get("Uin")
        # self.SubAccountUin = params.get("SubAccountUin")
        # self.RequestId = params.get("RequestId")


class BspImageRecognitionResponse(AbstractModel):
    """BspImageRecognition返回参数结构体

    """

    def __init__(self):
        """
        :param Data: 识别结果详情
        :type Data: :class:`tencentcloud.contentsecurity.v20190305.models.ImageData`
        :param RequestId: 唯一请求 ID，每次请求都会返回。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self.Data = None
        self.RequestId = None


    def _deserialize(self, params):
        if params.get("Data") is not None:
            self.Data = ImageData()
            self.Data._deserialize(params.get("Data"))
        self.RequestId = params.get("RequestId")


class BspOpenAfterPayServiceRequest(AbstractModel):
    """BspOpenAfterPayService请求参数结构体

    """

    def __init__(self):
        """
        :param Pid: pid.
        :type Pid: int
        :param Type: type.
        :type Type: str
        :param SubType: subtype.
        :type SubType: str
        """
        self.Pid = None
        self.Type = None
        self.SubType = None


    def _deserialize(self, params):
        self.Pid = params.get("Pid")
        self.Type = params.get("Type")
        self.SubType = params.get("SubType")


class BspOpenAfterPayServiceResponse(AbstractModel):
    """BspOpenAfterPayService返回参数结构体

    """

    def __init__(self):
        """
        :param RequestId: 唯一请求 ID，每次请求都会返回。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self.RequestId = None


    def _deserialize(self, params):
        self.RequestId = params.get("RequestId")


class BspOpenServiceRequest(AbstractModel):
    """BspOpenService请求参数结构体

    """

    def __init__(self):
        """
        :param UIN: 客户uin
        :type UIN: int
        :param APPID: 客户appid
        :type APPID: int
        :param ServicesId: 服务id
        :type ServicesId: int
        """
        self.UIN = None
        self.APPID = None
        self.ServicesId = None


    def _deserialize(self, params):
        self.UIN = params.get("UIN")
        self.APPID = params.get("APPID")
        self.ServicesId = params.get("ServicesId")


class BspOpenServiceResponse(AbstractModel):
    """BspOpenService返回参数结构体

    """

    def __init__(self):
        """
        :param Data: 服务开通详情
        :type Data: list of str
        :param RequestId: 唯一请求 ID，每次请求都会返回。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self.Data = None
        self.RequestId = None


    def _deserialize(self, params):
        self.Data = params.get("Data")
        self.RequestId = params.get("RequestId")


class BspSearchAllServiceNumRequest(AbstractModel):
    """BspSearchAllServiceNum请求参数结构体

    """

    def __init__(self):
        """
        :param Today: 当天日期
        :type Today: str
        :param YesterDay: 昨日日期
        :type YesterDay: str
        :param WeekFdate: 上周当天日期
        :type WeekFdate: str
        """
        self.Today = None
        self.YesterDay = None
        self.WeekFdate = None


    def _deserialize(self, params):
        self.Today = params.get("Today")
        self.YesterDay = params.get("YesterDay")
        self.WeekFdate = params.get("WeekFdate")


class BspSearchAllServiceNumResponse(AbstractModel):
    """BspSearchAllServiceNum返回参数结构体

    """

    def __init__(self):
        """
        :param Data: 返回top50数据详情
        :type Data: list of str
        :param RequestId: 唯一请求 ID，每次请求都会返回。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self.Data = None
        self.RequestId = None


    def _deserialize(self, params):
        self.Data = params.get("Data")
        self.RequestId = params.get("RequestId")


class BspSearchAllServiceOpensRequest(AbstractModel):
    """BspSearchAllServiceOpens请求参数结构体

    """


class BspSearchAllServiceOpensResponse(AbstractModel):
    """BspSearchAllServiceOpens返回参数结构体

    """

    def __init__(self):
        """
        :param Data: 客户服务开通详情信息
        :type Data: list of str
        :param RequestId: 唯一请求 ID，每次请求都会返回。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self.Data = None
        self.RequestId = None


    def _deserialize(self, params):
        self.Data = params.get("Data")
        self.RequestId = params.get("RequestId")


class BspSearchServiceOpensRequest(AbstractModel):
    """BspSearchServiceOpens请求参数结构体

    """

    def __init__(self):
        """
        :param ServicesId: 内容安全服务ID标识
        :type ServicesId: int
        """
        self.ServicesId = None


    def _deserialize(self, params):
        self.ServicesId = params.get("ServicesId")


class BspSearchServiceOpensResponse(AbstractModel):
    """BspSearchServiceOpens返回参数结构体

    """

    def __init__(self):
        """
        :param Data: 服务开通记录详情信息
        :type Data: list of str
        :param RequestId: 唯一请求 ID，每次请求都会返回。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self.Data = None
        self.RequestId = None


    def _deserialize(self, params):
        self.Data = params.get("Data")
        self.RequestId = params.get("RequestId")


class BspSereachServiceAllRequest(AbstractModel):
    """BspSereachServiceAll请求参数结构体

    """

    def __init__(self):
        """
        :param UIN: 客户uin
        :type UIN: int
        """
        self.UIN = None


    def _deserialize(self, params):
        self.UIN = params.get("UIN")


class BspSereachServiceAllResponse(AbstractModel):
    """BspSereachServiceAll返回参数结构体

    """

    def __init__(self):
        """
        :param Data: 用户开通服务信息
        :type Data: list of str
        :param RequestId: 唯一请求 ID，每次请求都会返回。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self.Data = None
        self.RequestId = None


    def _deserialize(self, params):
        self.Data = params.get("Data")
        self.RequestId = params.get("RequestId")


class BspStatisticsContentRequest(AbstractModel):
    """BspStatisticsContent请求参数结构体

    """

    def __init__(self):
        """
        :param StartFdate: 开始日期
        :type StartFdate: str
        :param EndFdate: 结束日期
        :type EndFdate: str
        :param ServicesId: 内容安全服务id标识
        :type ServicesId: int
        """
        self.StartFdate = None
        self.EndFdate = None
        self.ServicesId = None


    def _deserialize(self, params):
        self.StartFdate = params.get("StartFdate")
        self.EndFdate = params.get("EndFdate")
        self.ServicesId = params.get("ServicesId")


class BspStatisticsContentResponse(AbstractModel):
    """BspStatisticsContent返回参数结构体

    """

    def __init__(self):
        """
        :param Data: 时间区域内的用量详情和恶意占比信息
        :type Data: list of str
        :param RequestId: 唯一请求 ID，每次请求都会返回。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self.Data = None
        self.RequestId = None


    def _deserialize(self, params):
        self.Data = params.get("Data")
        self.RequestId = params.get("RequestId")


class BspStatisticsNumDistributionRequest(AbstractModel):
    """BspStatisticsNumDistribution请求参数结构体

    """

    def __init__(self):
        """
        :param StartFdate: 开始日期
        :type StartFdate: str
        :param EndFdate: 结束日期
        :type EndFdate: str
        """
        self.StartFdate = None
        self.EndFdate = None


    def _deserialize(self, params):
        self.StartFdate = params.get("StartFdate")
        self.EndFdate = params.get("EndFdate")


class BspStatisticsNumDistributionResponse(AbstractModel):
    """BspStatisticsNumDistribution返回参数结构体

    """

    def __init__(self):
        """
        :param Data: 返回客户数据明细
        :type Data: list of str
        :param RequestId: 唯一请求 ID，每次请求都会返回。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self.Data = None
        self.RequestId = None


    def _deserialize(self, params):
        self.Data = params.get("Data")
        self.RequestId = params.get("RequestId")


class BspSumUserRequestQuantityRequest(AbstractModel):
    """BspSumUserRequestQuantity请求参数结构体

    """

    def __init__(self):
        """
        :param StartFdate: 当前日期
        :type StartFdate: str
        :param UIN: 客户uin
        :type UIN: int
        :param EndFdate: 结束日期
        :type EndFdate: str
        """
        self.StartFdate = None
        self.UIN = None
        self.EndFdate = None


    def _deserialize(self, params):
        self.StartFdate = params.get("StartFdate")
        self.UIN = params.get("UIN")
        self.EndFdate = params.get("EndFdate")


class BspSumUserRequestQuantityResponse(AbstractModel):
    """BspSumUserRequestQuantity返回参数结构体

    """

    def __init__(self):
        """
        :param Data: 请求量明细数据
        :type Data: list of str
        :param RequestId: 唯一请求 ID，每次请求都会返回。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self.Data = None
        self.RequestId = None


    def _deserialize(self, params):
        self.Data = params.get("Data")
        self.RequestId = params.get("RequestId")


class BspTextRecognitionRequest(AbstractModel):
    """BspTextRecognition请求参数结构体

    """

    def __init__(self):
        """
        :param MessageContent: 识别的文本内容
        :type MessageContent: str
        """
        self.MessageContent = None


    def _deserialize(self, params):
        self.MessageContent = params.get("MessageContent")


class BspTextRecognitionResponse(AbstractModel):
    """BspTextRecognition返回参数结构体

    """

    def __init__(self):
        """
        :param Data: 识别结果
        :type Data: :class:`tencentcloud.contentsecurity.v20190305.models.TextData`
        :param RequestId: 唯一请求 ID，每次请求都会返回。定位问题时需要提供该次请求的 RequestId。
        :type RequestId: str
        """
        self.Data = None
        self.RequestId = None


    def _deserialize(self, params):
        if params.get("Data") is not None:
            self.Data = TextData()
            self.Data._deserialize(params.get("Data"))
        self.RequestId = params.get("RequestId")


class ImageData(AbstractModel):
    """图片识别结果

    """

    def __init__(self):
        """
        :param StatusCode: 公共错误码 0：表示成功 -1003表示图片处理超时；-1004表示文字处理超时；-1005表示内部处理异常；
        :type StatusCode: int
        :param Type: 恶意类型： 100:正常 20001:政治 20002:色情 20006:涉毒违法 24001:暴恐 21000:其他
        :type Type: int
        :param Data: 图片识别结果详情
        :type Data: list of ImageDetail
        """
        self.StatusCode = None
        self.Type = None
        self.Data = None


    def _deserialize(self, params):
        self.StatusCode = params.get("StatusCode")
        self.Type = params.get("Type")
        if params.get("Data") is not None:
            self.Data = []
            for item in params.get("Data"):
                obj = ImageDetail()
                obj._deserialize(item)
                self.Data.append(obj)


class ImageDetail(AbstractModel):
    """图片识别服务结果

    """

    def __init__(self):
        """
        :param Category: 识别类型 PornDetect FaceRecog IllegalDetect TerroristDetect OCRDetect SimDetect
        :type Category: str
        :param HitFlag: 是否恶意：0否1是
        :type HitFlag: int
        :param Score: 0-100 分值越高越恶意，其中OCRDetect与SimDetect无此字段
        :type Score: int
        :param Label: 特征中文描述，其中OCRDetect与SimDetect无此字段
        :type Label: str
        :param BeatTips: 打击原因，如命中的关键词(多个以分号分隔)  其中OCRDetect有此字段，其余识别类型无此字段
        :type BeatTips: str
        :param Level: 恶意等级：0：无恶意 1~3：数字越小恶意等级越高 其中OCRDetect有此字段，其余识别类型无此字段
        :type Level: int
        """
        self.Category = None
        self.HitFlag = None
        self.Score = None
        self.Label = None
        self.BeatTips = None
        self.Level = None


    def _deserialize(self, params):
        self.Category = params.get("Category")
        self.HitFlag = params.get("HitFlag")
        self.Score = params.get("Score")
        self.Label = params.get("Label")
        self.BeatTips = params.get("BeatTips")
        self.Level = params.get("Level")


class TextData(AbstractModel):
    """文本识别结果

    """

    def __init__(self):
        """
        :param StatusCode: 公共错误码 0：表示成功 -1003表示图片处理超时；-1004表示文字处理超时；-1005表示内部处理异常；
        :type StatusCode: int
        :param Type: 恶意类型： 100:正常 20001:政治 20002:色情 20006:涉毒违法 24001:暴恐 21000:其他
        :type Type: int
        :param BeatTips: 打击原因
        :type BeatTips: list of BeatTips
        """
        self.StatusCode = None
        self.Type = None
        self.BeatTips = None


    def _deserialize(self, params):
        self.StatusCode = params.get("StatusCode")
        self.Type = params.get("Type")
        if params.get("BeatTips") is not None:
            self.BeatTips = []
            for item in params.get("BeatTips"):
                obj = BeatTips()
                obj._deserialize(item)
                self.BeatTips.append(obj)