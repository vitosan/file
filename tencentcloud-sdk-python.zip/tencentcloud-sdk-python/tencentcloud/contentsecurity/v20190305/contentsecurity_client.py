# -*- coding: utf8 -*-
# Copyright (c) 2017-2018 THL A29 Limited, a Tencent company. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import json

from tencentcloud.common.exception.tencent_cloud_sdk_exception import TencentCloudSDKException
from tencentcloud.common.abstract_client import AbstractClient
from tencentcloud.contentsecurity.v20190305 import models


class ContentsecurityClient(AbstractClient):
    _apiVersion = '2019-03-05'
    # _endpoint = 'contentsecurity.tencentcloudapi.com'
    # _endpoint = 'contentsecurity.api3.401.tcecqpoc.fsphere.cn'
    # _endpoint = 'contentsecurity.api3.m14dlv330.tcecqpoc.fsphere.cn'
    _endpoint = 'contentsecurity.api3.test.yfm5.tcecqpoc.fsphere.cn'
    _endpoint = 'contentsecurity.api3.m14-2.tcecqpoc.fsphere.cn'
    _endpoint = 'contentsecurity.api3.yun.ccb.com'

    def BspAudioRecognition(self, request):
        """识别音频是否存在恶意信息

        :param request: 调用BspAudioRecognition所需参数的结构体。
        :type request: :class:`tencentcloud.contentsecurity.v20190305.models.BspAudioRecognitionRequest`
        :rtype: :class:`tencentcloud.contentsecurity.v20190305.models.BspAudioRecognitionResponse`

        """
        try:
            params = request._serialize()
            body = self.call("BspAudioRecognition", params)
            response = json.loads(body)
            if "Error" not in response["Response"]:
                model = models.BspAudioRecognitionResponse()
                model._deserialize(response["Response"])
                return model
            else:
                code = response["Response"]["Error"]["Code"]
                message = response["Response"]["Error"]["Message"]
                reqid = response["Response"]["RequestId"]
                raise TencentCloudSDKException(code, message, reqid)
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(e.message, e.message)

    def BspCloseService(self, request):
        """单个服务关闭接口

        :param request: 调用BspCloseService所需参数的结构体。
        :type request: :class:`tencentcloud.contentsecurity.v20190305.models.BspCloseServiceRequest`
        :rtype: :class:`tencentcloud.contentsecurity.v20190305.models.BspCloseServiceResponse`

        """
        try:
            params = request._serialize()
            body = self.call("BspCloseService", params)
            response = json.loads(body)
            if "Error" not in response["Response"]:
                model = models.BspCloseServiceResponse()
                model._deserialize(response["Response"])
                return model
            else:
                code = response["Response"]["Error"]["Code"]
                message = response["Response"]["Error"]["Message"]
                reqid = response["Response"]["RequestId"]
                raise TencentCloudSDKException(code, message, reqid)
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(e.message, e.message)

    def BspImageRecognition(self, request):
        """识别图片是否存在恶意信息

        :param request: 调用BspImageRecognition所需参数的结构体。
        :type request: :class:`tencentcloud.contentsecurity.v20190305.models.BspImageRecognitionRequest`
        :rtype: :class:`tencentcloud.contentsecurity.v20190305.models.BspImageRecognitionResponse`

        """
        try:
            params = request._serialize()
            body = self.call("BspImageRecognition", params)
            response = json.loads(body)
            if "Error" not in response["Response"]:
                model = models.BspImageRecognitionResponse()
                model._deserialize(response["Response"])
                return model
            else:
                code = response["Response"]["Error"]["Code"]
                message = response["Response"]["Error"]["Message"]
                reqid = response["Response"]["RequestId"]
                raise TencentCloudSDKException(code, message, reqid)
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(e.message, e.message)

    def BspOpenAfterPayService(self, request):
        """客户点击开通服务接口

        :param request: 调用BspOpenAfterPayService所需参数的结构体。
        :type request: :class:`tencentcloud.contentsecurity.v20190305.models.BspOpenAfterPayServiceRequest`
        :rtype: :class:`tencentcloud.contentsecurity.v20190305.models.BspOpenAfterPayServiceResponse`

        """
        try:
            params = request._serialize()
            body = self.call("BspOpenAfterPayService", params)
            response = json.loads(body)
            if "Error" not in response["Response"]:
                model = models.BspOpenAfterPayServiceResponse()
                model._deserialize(response["Response"])
                return model
            else:
                code = response["Response"]["Error"]["Code"]
                message = response["Response"]["Error"]["Message"]
                reqid = response["Response"]["RequestId"]
                raise TencentCloudSDKException(code, message, reqid)
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(e.message, e.message)

    def BspOpenService(self, request):
        """开通内容安全服务

        :param request: 调用BspOpenService所需参数的结构体。
        :type request: :class:`tencentcloud.contentsecurity.v20190305.models.BspOpenServiceRequest`
        :rtype: :class:`tencentcloud.contentsecurity.v20190305.models.BspOpenServiceResponse`

        """
        try:
            params = request._serialize()
            body = self.call("BspOpenService", params)
            response = json.loads(body)
            if "Error" not in response["Response"]:
                model = models.BspOpenServiceResponse()
                model._deserialize(response["Response"])
                return model
            else:
                code = response["Response"]["Error"]["Code"]
                message = response["Response"]["Error"]["Message"]
                reqid = response["Response"]["RequestId"]
                raise TencentCloudSDKException(code, message, reqid)
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(e.message, e.message)

    def BspSearchAllServiceNum(self, request):
        """Top50租户

        :param request: 调用BspSearchAllServiceNum所需参数的结构体。
        :type request: :class:`tencentcloud.contentsecurity.v20190305.models.BspSearchAllServiceNumRequest`
        :rtype: :class:`tencentcloud.contentsecurity.v20190305.models.BspSearchAllServiceNumResponse`

        """
        try:
            params = request._serialize()
            body = self.call("BspSearchAllServiceNum", params)
            response = json.loads(body)
            if "Error" not in response["Response"]:
                model = models.BspSearchAllServiceNumResponse()
                model._deserialize(response["Response"])
                return model
            else:
                code = response["Response"]["Error"]["Code"]
                message = response["Response"]["Error"]["Message"]
                reqid = response["Response"]["RequestId"]
                raise TencentCloudSDKException(code, message, reqid)
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(e.message, e.message)

    def BspSearchAllServiceOpens(self, request):
        """内容安全查询所有服务开通详情

        :param request: 调用BspSearchAllServiceOpens所需参数的结构体。
        :type request: :class:`tencentcloud.contentsecurity.v20190305.models.BspSearchAllServiceOpensRequest`
        :rtype: :class:`tencentcloud.contentsecurity.v20190305.models.BspSearchAllServiceOpensResponse`

        """
        try:
            params = request._serialize()
            body = self.call("BspSearchAllServiceOpens", params)
            response = json.loads(body)
            if "Error" not in response["Response"]:
                model = models.BspSearchAllServiceOpensResponse()
                model._deserialize(response["Response"])
                return model
            else:
                code = response["Response"]["Error"]["Code"]
                message = response["Response"]["Error"]["Message"]
                reqid = response["Response"]["RequestId"]
                raise TencentCloudSDKException(code, message, reqid)
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(e.message, e.message)

    def BspSearchServiceOpens(self, request):
        """内容安全查询单个服务是否开通

        :param request: 调用BspSearchServiceOpens所需参数的结构体。
        :type request: :class:`tencentcloud.contentsecurity.v20190305.models.BspSearchServiceOpensRequest`
        :rtype: :class:`tencentcloud.contentsecurity.v20190305.models.BspSearchServiceOpensResponse`

        """
        try:
            params = request._serialize()
            body = self.call("BspSearchServiceOpens", params)
            response = json.loads(body)
            if "Error" not in response["Response"]:
                model = models.BspSearchServiceOpensResponse()
                model._deserialize(response["Response"])
                return model
            else:
                code = response["Response"]["Error"]["Code"]
                message = response["Response"]["Error"]["Message"]
                reqid = response["Response"]["RequestId"]
                raise TencentCloudSDKException(code, message, reqid)
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(e.message, e.message)

    def BspSereachServiceAll(self, request):
        """租户服务开通信息

        :param request: 调用BspSereachServiceAll所需参数的结构体。
        :type request: :class:`tencentcloud.contentsecurity.v20190305.models.BspSereachServiceAllRequest`
        :rtype: :class:`tencentcloud.contentsecurity.v20190305.models.BspSereachServiceAllResponse`

        """
        try:
            params = request._serialize()
            body = self.call("BspSereachServiceAll", params)
            response = json.loads(body)
            if "Error" not in response["Response"]:
                model = models.BspSereachServiceAllResponse()
                model._deserialize(response["Response"])
                return model
            else:
                code = response["Response"]["Error"]["Code"]
                message = response["Response"]["Error"]["Message"]
                reqid = response["Response"]["RequestId"]
                raise TencentCloudSDKException(code, message, reqid)
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(e.message, e.message)

    def BspStatisticsContent(self, request):
        """内容安全用量详情和恶意占比

        :param request: 调用BspStatisticsContent所需参数的结构体。
        :type request: :class:`tencentcloud.contentsecurity.v20190305.models.BspStatisticsContentRequest`
        :rtype: :class:`tencentcloud.contentsecurity.v20190305.models.BspStatisticsContentResponse`

        """
        try:
            params = request._serialize()
            body = self.call("BspStatisticsContent", params)
            response = json.loads(body)
            if "Error" not in response["Response"]:
                model = models.BspStatisticsContentResponse()
                model._deserialize(response["Response"])
                return model
            else:
                code = response["Response"]["Error"]["Code"]
                message = response["Response"]["Error"]["Message"]
                reqid = response["Response"]["RequestId"]
                raise TencentCloudSDKException(code, message, reqid)
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(e.message, e.message)

    def BspStatisticsNumDistribution(self, request):
        """内容安全服务用量分布图

        :param request: 调用BspStatisticsNumDistribution所需参数的结构体。
        :type request: :class:`tencentcloud.contentsecurity.v20190305.models.BspStatisticsNumDistributionRequest`
        :rtype: :class:`tencentcloud.contentsecurity.v20190305.models.BspStatisticsNumDistributionResponse`

        """
        try:
            params = request._serialize()
            body = self.call("BspStatisticsNumDistribution", params)
            response = json.loads(body)
            if "Error" not in response["Response"]:
                model = models.BspStatisticsNumDistributionResponse()
                model._deserialize(response["Response"])
                return model
            else:
                code = response["Response"]["Error"]["Code"]
                message = response["Response"]["Error"]["Message"]
                reqid = response["Response"]["RequestId"]
                raise TencentCloudSDKException(code, message, reqid)
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(e.message, e.message)

    def BspSumUserRequestQuantity(self, request):
        """请求数分布和明细记录

        :param request: 调用BspSumUserRequestQuantity所需参数的结构体。
        :type request: :class:`tencentcloud.contentsecurity.v20190305.models.BspSumUserRequestQuantityRequest`
        :rtype: :class:`tencentcloud.contentsecurity.v20190305.models.BspSumUserRequestQuantityResponse`

        """
        try:
            params = request._serialize()
            body = self.call("BspSumUserRequestQuantity", params)
            response = json.loads(body)
            if "Error" not in response["Response"]:
                model = models.BspSumUserRequestQuantityResponse()
                model._deserialize(response["Response"])
                return model
            else:
                code = response["Response"]["Error"]["Code"]
                message = response["Response"]["Error"]["Message"]
                reqid = response["Response"]["RequestId"]
                raise TencentCloudSDKException(code, message, reqid)
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(e.message, e.message)

    def BspTextRecognition(self, request):
        """识别文本是否存在恶意信息

        :param request: 调用BspTextRecognition所需参数的结构体。
        :type request: :class:`tencentcloud.contentsecurity.v20190305.models.BspTextRecognitionRequest`
        :rtype: :class:`tencentcloud.contentsecurity.v20190305.models.BspTextRecognitionResponse`

        """
        try:
            params = request._serialize()
            body = self.call("BspTextRecognition", params)
            response = json.loads(body)
            if "Error" not in response["Response"]:
                model = models.BspTextRecognitionResponse()
                model._deserialize(response["Response"])
                return model
            else:
                code = response["Response"]["Error"]["Code"]
                message = response["Response"]["Error"]["Message"]
                reqid = response["Response"]["RequestId"]
                raise TencentCloudSDKException(code, message, reqid)
        except Exception as e:
            if isinstance(e, TencentCloudSDKException):
                raise
            else:
                raise TencentCloudSDKException(e.message, e.message)
