# -*- coding: utf-8 -*-
import os
import ssl
ssl._create_default_https_context = ssl._create_unverified_context
from tencentcloud.common import credential
from tencentcloud.common.profile import client_profile
from tencentcloud.common.profile import http_profile
from tencentcloud.common.profile.client_profile import ClientProfile
from tencentcloud.common.profile.http_profile import HttpProfile
from tencentcloud.common.exception.tencent_cloud_sdk_exception import TencentCloudSDKException
# 导入对应产品模块的client models。
from tencentcloud.contentsecurity.v20190305 import contentsecurity_client, models
try:
    # 实例化一个http选项，可选的，没有特殊需求可以跳过。
    # 实例化一个认证对象，入参需要传入腾讯云账户secretId，secretKey
    cred = credential.Credential("AKIDj8CwHIXNRg9dLBaW1cZuvfk6LUZmYNSg","A4xBNheY9RSgwMmKc6I2sRjkmVteAFzQ")
    #cred = credential.Credential("AKIDjAG1SYfCkxpNaSxEPGn0tTkhKddJkhPn","D6ftnNAdlZ5KFq73fxuZuuaxzh47XdPq")
    # 子账号 cms_test	yYsZqxpn9E.  账号ID 100004603460 APPID  1255000454
    #cred = credential.Credential("AKIDPXLnuhOGJ1OR8VHDZwzi6AwNTEejjtyi","Yld9RO0ybtrUmjLcofCPHvECp74fvrUn")
    # 文本测试
    client = contentsecurity_client.ContentsecurityClient(cred,"")
    # print (client._endpoint)
    # # 实例化一个请求对象
    # req = models.BspTextRecognitionRequest()
    # req.MessageContent = '测试内容'
    # print (req)
    # resp = client.BspTextRecognition(req)
    # print(resp.to_json_string())

    #图片测试
    req = models.BspImageRecognitionRequest()
    req.FileUrl ='http://testbsp-1255000058.cos.hongkong.m14dlv330.cos.tcecqpoc.fsphere.cn/image/20190729/a556f732260b334dbadb4a7901ae3964'
    req.FileContent=''
    print (req)
    # 通过client对象调用想要访问的接口，需要传入请求对象
    resp = client.BspImageRecognition(req)
    print(resp.to_json_string())

    
    # # 音频测试
    # req = models.BspAudioRecognitionRequest()
    # req.FileUrl = 'http://10.10.0.45:8080/data/home/oicq/yupeiye/files/shortv.m4a'
    # # 通过client对象调用想要访问的接口，需要传入请求对象
    # resp = client.BspAudioRecognition(req)
    # print(resp.to_json_string())


except TencentCloudSDKException as err:
    print(err)
