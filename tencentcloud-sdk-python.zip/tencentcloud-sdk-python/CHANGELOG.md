# CHANGELOG

## latest

* fix #6: print all attributs, includes those value is null

## 3.0.27

* update api

## 3.0.26

* update api

## 3.0.25

* update api

## 3.0.24

* update api

## 3.0.23

* update api

## 3.0.22

* update api

## 3.0.21

* update api

## 3.0.20

* update api
* fix #14: use correct host name instead of proxy host name when behind proxy, due to [python issue 7776](https://bugs.python.org/issue7776)

## 3.0.19

* update api

## 3.0.18

* update api

## 3.0.17

* update api

## 3.0.16

* update api

## 3.0.15

* update api

## 3.0.14

* update api

